# transfer.sh-bot
[![made-with-python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org/) [![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/)

Telegram bot to upload files to transfer.sh remotely

### My Thanks to :heart: 
  - [MaheshMalekar](https://t.me/MaheshMalekar)
    
### Requirements
 - Bot Token (get it from [@BotFather](https://t.me/BotFather))
 - API ID
 - API HASH 
 
Visit [this](https://my.telegram.org/) link to get API ID and API HASH.

### Host on Heroku or on your own Server

 `Make sure you have added your bot token, api id, api_hash before you host on Heroku or on your own Server`
